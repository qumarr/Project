<?php

$config['site_name'] = 'School Management';
